$(document).ready(function() {
    $("#profile-pic-img").click(function() {
        console.log("Clicado!");
        $("#dropdown").toggle();
    });
});
